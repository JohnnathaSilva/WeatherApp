# WeatherApp
O aplicativo deve consumir a localização atual do usuário e exibir na interface o endereço atual e os dados climáticos da região
